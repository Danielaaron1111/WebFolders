const toggleButton = document.querySelector('.toggle-btn');

toggleButton.addEventListener('click', (e) => {
    e.stopPropagation();
    document.querySelector('nav').classList.toggle('expanded');
});

// Submenu toggle for mobile (desktop uses CSS hover)
const submenuToggle = document.querySelector('.submenu-toggle');

submenuToggle.addEventListener('click', (e) => {
    if (window.innerWidth < 1080) {
        e.preventDefault();
        document.querySelector('.submenu').classList.toggle('open');
    }
});
